<?php

require '../src/database/db.php';

session_start();

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (!isset($conn)) {
    die("Database connection not established.");
}

$email = '';
$password = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    echo "<h1>Login</h1>";
    $emailOrUsername = $_POST['email'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM users WHERE email = '$emailOrUsername' OR username = '$emailOrUsername' and password = '$password'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        
        $row = $result->fetch_assoc();        
        $_SESSION['email'] = $row['email'];
        $_SESSION['firstName'] = $row['firstName'];
        $_SESSION['lastName'] = $row['lastName'];  
        $_SESSION['id'] = $row['id'];
        header("Location: /sammyverse/index.php");
        exit();            
        
    } else {
        echo "<style>
                p { color: red; font-size: 25px; text-align: center; }
            </style>";
        echo "<p>User Not Found, Invalid Email or Password</p>";
        echo "<p><a href='register.php'>Please Register</a> or <a href='#'>Forget Password</a></p>";
    }

    $conn->close();
}




?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
        body{
            margin: 0;
            padding: 0;
            background-color: #10375C;
            color: #F4F6FF;
            font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;            
        }

        h1{
            color: #EB8317;
        }
        
        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
        }

        label{
            
            font-size: larger;
            
        }

        input{
            font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
            font-size: large;
            width: 100%;
            border: none;
            border-radius: 5px;
            padding: 5px;
            margin-top: 5px;
        }

        button{
            margin-top: 30px; 
            font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
            font-size: large;
            width: 100%;
            background-color: #F3C623;
            border: none;
            border-radius: 5px;
            padding: 8px;
        }

        .email{
            margin-bottom: 20px;
            margin-top: 20px;
        }

        a{
            text-decoration: none;
            color: #F3C623;
        }

        p{
            font-size: 17px;
        }

        
        
        
    </style>
</head>
<body>
    
    <div class="container">
        <h1>Welcome to SammyVerse</h1>

        <h2>Login</h2>
        
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="email">
                <label for="email">Email:</label><br>
                <input type="text" name="email" placeholder="Enter Email or Username" required>
            </div>
            <div class="password">
                <label for="password">Password:</label><br>
                <input type="password" name="password" placeholder="Enter Password" required>
            </div>
            <div class="button">
                <button type="submit" name="login">Login</button>
            </div>
        </form>

            <p>Dont have an account? <a href="register.php">Register</a></p>
            
    </div>
</body>
</html>