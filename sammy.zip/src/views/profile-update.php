<?php

require '../database/db.php';

session_start();

if(!isset($_SESSION['id'])) {   
    header('Location: /public/login.php');
    exit();
}

$userId = $_SESSION['id'];


// Fetch user data
$stmt = $conn->prepare("SELECT username, firstName, lastName, email, profile_picture FROM users WHERE id = ?");
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if (!$user) {
    die("User not found.");
}




?>

<?php include '../includes/header.php'; ?>  

<div class="">
    <h1 class="text-3xl font-bold mb-6">Update Profile</h1>
    <hr>

    <div class="text-2xl font-bold mb-6 bg-[#0e285c] rounded shadow-lg p-6 mt-6">
        <h2 class="text-xl font-bold mb-6">Account Settings</h2>

        <form action="" method="POST">
            <label for="username">Username:</label><br>
            <div class="flex w-full mb-6">
            <input type="text" placeholder="<?php echo $user['username']; ?>" name="username" class="flex-1 p-3 bg-[#0b49c5] text-slate-100 text-lg rounded-l border-none outline-none">
            <button class="p-3 bg-green-500 text-white text-lg rounded-r hover:bg-green-600 transition ease-in-out duration-200"  type="submit" name="username-update">
                Update
            </button>
            </div>
        </form>

        <form action="" method="POST">
            <label for="name">firstName and lastName:</label>
            <div class="flex w-full mb-6">
            <input type="text" placeholder="<?php echo $user['firstName'] . ' ' . $user['lastName']; ?>" name="name" class="flex-1 p-3 bg-[#0b49c5] text-slate-100 text-lg rounded-l border-none outline-none">
            <button class="p-3 bg-green-500 text-white text-lg rounded-r hover:bg-green-600 transition ease-in-out duration-200"  type="submit" name="username-update">
                Update
            </button>
            </div>
        </form>

        <form action="" method="POST">
            <label for="email" class="block mb-2 text-white">Email:</label>
            <div class="flex w-full mb-6">
                <input type="text" placeholder="<?php echo $user['email']; ?>" name="email" class="flex-1 p-3 bg-[#0b49c5] text-slate-100 text-lg rounded-l border-none outline-none">
                <button type="submit" name="username-update" class="p-3 bg-green-500 text-white text-lg rounded-r hover:bg-green-600 transition ease-in-out duration-200">
                    Update
                </button>
            </div>
        </form>


        <form action="" method="POST">
            <label for="username">Password:</label><br>
            <div class="flex w-full mb-6">
            <input type="text" placeholder="" name="password" class="flex-1 p-3 bg-[#0b49c5] text-slate-100 text-lg rounded-l border-none outline-none">
            <button class="p-3 bg-green-500 text-white text-lg rounded-r hover:bg-green-600 transition ease-in-out duration-200"  type="submit" name="password-update">
                Update
            </button>
            </div>
        </form>
</div>

<?php include '../includes/footer.php';?>